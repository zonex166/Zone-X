// ===== SCROLL ANIMATIONS =====
function initScrollReveal() {
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');

  if (revealElements.length === 0) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  revealElements.forEach(el => observer.observe(el));
}

// ===== PRODUCT CARD STAGGER =====
function initStaggerAnimation() {
  const grids = document.querySelectorAll('.products-grid');
  grids.forEach(grid => {
    const cards = grid.querySelectorAll('.product-card');
    cards.forEach((card, i) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(30px)';
      card.style.transition = `opacity 0.6s ease ${i * 0.08}s, transform 0.6s ease ${i * 0.08}s`;

      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
            observer.unobserve(card);
          }
        });
      }, { threshold: 0.1 });

      observer.observe(card);
    });
  });
}

// ===== PARALLAX HERO =====
function initParallax() {
  const hero = document.querySelector('.hero');
  if (!hero) return;

  window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const rate = scrolled * -0.3;
    hero.style.backgroundPositionY = `${rate}px`;
  }, { passive: true });
}

// ===== SMOOTH COUNTER =====
function animateCounter(el, target, duration) {
  const start = 0;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    const current = Math.floor(start + (target - start) * eased);
    el.textContent = current.toLocaleString();

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

// ===== HERO PARTICLES (hearts) =====
function initHeroParticles() {
  const hero = document.querySelector('.hero');
  if (!hero) return;

  const container = document.createElement('div');
  container.className = 'hero-particles';
  hero.prepend(container);

  for (let i = 0; i < 12; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.textContent = '♥';
    particle.style.cssText = `
      position: absolute;
      left: ${Math.random() * 100}%;
      top: 100%;
      font-size: ${16 + Math.random() * 14}px;
      color: rgba(212, 38, 58, ${0.12 + Math.random() * 0.18});
      animation: particle-float ${8 + Math.random() * 10}s ease-in-out ${Math.random() * 6}s infinite;
      pointer-events: none;
      user-select: none;
      transform: translateY(0);
    `;
    container.appendChild(particle);
  }
}

// ===== IMAGE LAZY LOAD =====
function initLazyLoading() {
  const images = document.querySelectorAll('.product-img, .main-image');
  if (images.length === 0) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        const src = img.getAttribute('data-src');
        if (src) {
          img.src = src;
          img.removeAttribute('data-src');
        }
        observer.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });

  images.forEach(img => {
    if (img.src && !img.complete) {
      observer.observe(img);
    }
  });
}

// ===== HOVER GLOW EFFECT =====
function initHoverGlow() {
  const cards = document.querySelectorAll('.product-card');
  cards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);
    });
  });
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  initScrollReveal();
  initStaggerAnimation();
  initHeroParticles();
  initLazyLoading();

  // On product detail page
  if (document.querySelector('.product-detail')) {
    initParallax();
  }
});
