$port = 8080
$root = "C:\Users\SCORPI\Desktop\Zone X\site"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Start()
Write-Host "Serveur démarré sur http://localhost:$port"

while ($listener.IsListening) {
  $context = $listener.GetContext()
  $request = $context.Request
  $response = $context.Response

  $path = $request.Url.LocalPath
  if ($path -eq '/') { $path = '/index.html' }
  $filePath = $root + $path.Replace('/', '\')

  if (Test-Path $filePath) {
    $ext = [System.IO.Path]::GetExtension($filePath)
    $mime = @{
      '.html' = 'text/html'
      '.css' = 'text/css'
      '.js' = 'application/javascript'
      '.png' = 'image/png'
      '.jpg' = 'image/jpeg'
      '.jpeg' = 'image/jpeg'
      '.webp' = 'image/webp'
      '.ico' = 'image/x-icon'
    }
    $contentType = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
    $response.ContentType = $contentType
    $buffer = [System.IO.File]::ReadAllBytes($filePath)
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
  } else {
    $response.StatusCode = 404
    $buffer = [Text.Encoding]::UTF8.GetBytes('404 - Not Found')
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
  }
  $response.Close()
}
