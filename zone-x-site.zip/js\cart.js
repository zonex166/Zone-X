// ===== CART =====
let cart = JSON.parse(localStorage.getItem('zonex_cart')) || [];

function saveCart() {
  localStorage.setItem('zonex_cart', JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  document.querySelectorAll('.cart-count').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

function addToCart(productId, qty) {
  qty = qty || 1;
  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: productId, qty: qty });
  }
  saveCart();
  showToast('Produit ajouté au panier');
  updateCartCount();
}

function removeFromCart(productId) {
  cart = cart.filter(item => item.id !== productId);
  saveCart();
  renderCart();
}

function updateQty(productId, delta) {
  const item = cart.find(item => item.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(productId);
    return;
  }
  saveCart();
  renderCart();
}

function clearCart() {
  cart = [];
  saveCart();
  renderCart();
}

function getCartTotal() {
  return cart.reduce((sum, item) => {
    const product = products.find(p => p.id === item.id);
    return sum + (product ? product.price * item.qty : 0);
  }, 0);
}

function getCartCount() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

// ===== TOAST =====
function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 2500);
}

// ===== RENDER CART =====
function renderCart() {
  const container = document.getElementById('cart-items');
  const summary = document.getElementById('cart-summary');
  const empty = document.getElementById('cart-empty');

  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = '';
    if (empty) empty.style.display = 'block';
    if (summary) summary.style.display = 'none';
    return;
  }

  if (empty) empty.style.display = 'none';
  if (summary) summary.style.display = 'block';

  let html = '';
  cart.forEach(item => {
    const product = products.find(p => p.id === item.id);
    if (!product) return;
    html += `
      <div class="cart-item" data-id="${product.id}">
        <img src="${product.image}" alt="${product.name}" onerror="this.src='https://via.placeholder.com/100x100/222/e63946?text=Zone+X'">
        <div class="cart-item-info">
          <h3>${product.name}</h3>
          <div class="cart-item-price">${product.price.toLocaleString()} FCFA</div>
        </div>
        <div class="cart-item-total">
          <div class="price">${(product.price * item.qty).toLocaleString()} FCFA</div>
          <button class="remove-btn" onclick="removeFromCart(${product.id})"><i class="fas fa-trash"></i> Retirer</button>
        </div>
        <div class="cart-item-qty">
          <button onclick="updateQty(${product.id}, -1)">−</button>
          <span>${item.qty}</span>
          <button onclick="updateQty(${product.id}, 1)">+</button>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;

  if (summary) {
    const subtotal = getCartTotal();
    const delivery = 0; // à déterminer selon la ville
    document.getElementById('cart-subtotal').textContent = subtotal.toLocaleString() + ' FCFA';
    document.getElementById('cart-total').textContent = subtotal.toLocaleString() + ' FCFA';
  }
}

// ===== GENERATE INVOICE =====
function generateInvoiceNumber() {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replace(/-/g, '');
  const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
  return `ZX-${date}-${random}`;
}

function getInvoiceHTML(orderData) {
  const invoiceNumber = generateInvoiceNumber();
  const date = new Date().toLocaleDateString('fr-FR', {
    day: 'numeric', month: 'long', year: 'numeric'
  });

  let rows = '';
  let total = 0;
  (orderData.items || cart).forEach(item => {
    const product = products.find(p => p.id === (item.id || item.productId));
    if (!product) return;
    const lineTotal = product.price * item.qty;
    total += lineTotal;
    rows += `
      <tr>
        <td>${product.name}</td>
        <td class="text-right">${item.qty}</td>
        <td class="text-right">${product.price.toLocaleString()} FCFA</td>
        <td class="text-right">${lineTotal.toLocaleString()} FCFA</td>
      </tr>
    `;
  });

  return {
    invoiceNumber,
    html: `
      <div class="invoice-header">
        <div>
          <h2>ZONE X</h2>
          <div class="invoice-number">Facture ${invoiceNumber}</div>
        </div>
        <div style="text-align:right">
          <div style="color:#888;font-size:0.85rem">Date: ${date}</div>
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Produit</th>
            <th class="text-right">Qté</th>
            <th class="text-right">Prix unitaire</th>
            <th class="text-right">Total</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
        <tfoot>
          <tr class="total-row">
            <td colspan="3" class="text-right">TOTAL</td>
            <td class="text-right">${total.toLocaleString()} FCFA</td>
          </tr>
        </tfoot>
      </table>
      <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid #333;font-size:0.85rem;color:#888">
        <p><strong>Client:</strong> ${orderData.nom} ${orderData.prenom}</p>
        <p><strong>Téléphone:</strong> ${orderData.telephone}</p>
        <p><strong>Email:</strong> ${orderData.email || 'Non renseigné'}</p>
        <p><strong>Ville:</strong> ${orderData.ville}</p>
        <p><strong>Adresse:</strong> ${orderData.adresse}</p>
        <p><strong>Mode de paiement:</strong> ${orderData.paiement || 'Non spécifié'}</p>
        ${orderData.notes ? `<p><strong>Notes:</strong> ${orderData.notes}</p>` : ''}
      </div>
    `,
    total
  };
}

// ===== WHATSAPP ORDER =====
function sendOrderWhatsApp(orderData) {
  const phone = '237622395039'; // À remplacer par le vrai numéro
  const invoice = getInvoiceHTML(orderData);

  let message = '*NOUVELLE COMMANDE ZONE X*';
  message += `\nFacture: ${invoice.invoiceNumber}`;
  message += `\n\n*Client:* ${orderData.nom} ${orderData.prenom}`;
  message += `\n*Tél:* ${orderData.telephone}`;
  message += `\n*Email:* ${orderData.email || 'Non renseigné'}`;
  message += `\n*Ville:* ${orderData.ville}`;
  message += `\n*Adresse:* ${orderData.adresse}`;
  message += `\n*Paiement:* ${orderData.paiement || 'Non spécifié'}`;
  message += `\n*Notes:* ${orderData.notes || 'Aucune'}`;
  message += `\n\n*ARTICLES COMMANDÉS:*`;

  (orderData.items || cart).forEach(item => {
    const product = products.find(p => p.id === (item.id || item.productId));
    if (!product) return;
    message += `\n- ${product.name} x${item.qty} = ${(product.price * item.qty).toLocaleString()} FCFA`;
  });

  message += `\n\n*TOTAL: ${invoice.total.toLocaleString()} FCFA*`;
  message += `\n\nMerci de votre commande ! 🎉`;

  const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

// ===== DOWNLOAD INVOICE PDF =====
function downloadInvoicePDF(orderData) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const invoice = getInvoiceHTML(orderData);
  let total = 0;

  // Couleurs
  const red = [212, 38, 58];
  const gold = [255, 215, 0];
  const dark = [20, 20, 20];
  const gray = [136, 136, 136];

  // En-tête
  doc.setFillColor(...red);
  doc.rect(0, 0, 210, 35, 'F');
  doc.setFontSize(20);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('ZONE X', 105, 18, { align: 'center' });
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Boutique Erotique Premium', 105, 27, { align: 'center' });

  // Infos facture
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`Facture: ${invoice.invoiceNumber}`, 15, 48);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(...gray);
  doc.text(`Date: ${new Date().toLocaleDateString('fr-FR')}`, 15, 55);

  // Infos client
  doc.setDrawColor(...red);
  doc.setLineWidth(0.5);
  doc.line(15, 62, 195, 62);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('INFORMATIONS CLIENT', 15, 70);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(50, 50, 50);

  const clientInfo = [
    [`Client:`, `${orderData.nom} ${orderData.prenom}`],
    [`Telephone:`, orderData.telephone],
    [`Email:`, orderData.email || 'Non renseigne'],
    [`Ville:`, orderData.ville],
    [`Adresse:`, orderData.adresse],
    [`Paiement:`, orderData.paiement || 'Non specifie'],
  ];
  if (orderData.notes) clientInfo.push([`Notes:`, orderData.notes]);

  let y = 78;
  clientInfo.forEach(([label, value]) => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...gray);
    doc.text(label, 15, y);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(50, 50, 50);
    doc.text(value, 55, y);
    y += 6;
  });

  // Tableau articles
  y = Math.max(y + 5, 130);
  doc.setDrawColor(...red);
  doc.setLineWidth(0.5);
  doc.line(15, y, 195, y);
  y += 5;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('ARTICLES COMMANDES', 15, y);
  y += 8;

  // En-têtes tableau
  doc.setFillColor(...dark);
  doc.rect(15, y, 180, 8, 'F');
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('PRODUIT', 18, y + 5.5);
  doc.text('QTE', 140, y + 5.5, { align: 'center' });
  doc.text('TOTAL', 185, y + 5.5, { align: 'right' });
  y += 12;

  (orderData.items || cart).forEach((item, i) => {
    const product = products.find(p => p.id === (item.id || item.productId));
    if (!product) return;
    const lineTotal = product.price * item.qty;
    total += lineTotal;

    if (y > 270) {
      doc.addPage();
      y = 20;
    }

    if (i % 2 === 0) {
      doc.setFillColor(245, 245, 245);
      doc.rect(15, y - 3, 180, 8, 'F');
    }

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(50, 50, 50);
    doc.text(product.name.substring(0, 40), 18, y + 1);
    doc.text(`${item.qty}`, 140, y + 1, { align: 'center' });
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(...gold);
    doc.text(`${lineTotal.toLocaleString()} FCFA`, 185, y + 1, { align: 'right' });
    y += 8;
  });

  // Total
  y += 3;
  doc.setDrawColor(...red);
  doc.setLineWidth(0.5);
  doc.line(130, y, 195, y);
  y += 6;
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('TOTAL', 140, y, { align: 'center' });
  doc.setTextColor(...red);
  doc.text(`${total.toLocaleString()} FCFA`, 185, y, { align: 'right' });

  // Pied de page
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(...gray);
    doc.text('Zone X - Yaounde, Cameroun', 105, 290, { align: 'center' });
    doc.text(`Page ${i}/${pageCount}`, 185, 290, { align: 'right' });
  }

  doc.save(`facture-zonex-${invoice.invoiceNumber}.pdf`);
  showToast('Facture PDF téléchargée');
}

// ===== EMAILJS CONFIG =====
const EMAILJS_CONFIG = {
  SERVICE_ID: 'service_87ji7hn',
  TEMPLATE_ID: 'template_wbib6y8',
  PUBLIC_KEY: 'JELeL1ZSKksWlHq8x'
};

// ===== EMAIL ORDER =====
function sendOrderEmail(orderData) {
  return new Promise((resolve) => {
    const invoice = getInvoiceHTML(orderData);
    let total = 0;

    (orderData.items || cart).forEach(item => {
      const product = products.find(p => p.id === (item.id || item.productId));
      if (!product) return;
      total += product.price * item.qty;
    });

    if (typeof emailjs !== 'undefined') {
      const orders = [];
      (orderData.items || cart).forEach(item => {
        const product = products.find(p => p.id === (item.id || item.productId));
        if (!product) return;
        orders.push({ name: product.name, units: item.qty, price: product.price.toLocaleString(), total: (product.price * item.qty).toLocaleString() });
      });

      emailjs.send(EMAILJS_CONFIG.SERVICE_ID, EMAILJS_CONFIG.TEMPLATE_ID, {
        order_id: invoice.invoiceNumber,
        from_name: `${orderData.nom} ${orderData.prenom}`,
        orders: orders,
        cost: { shipping: '0', tax: '0', total: total.toLocaleString() },
        email: orderData.email || 'jspkite10@gmail.com'
      }, EMAILJS_CONFIG.PUBLIC_KEY)
      .then(() => { showToast('Commande envoyée par email'); resolve(true); })
      .catch(() => { fallbackEmail(orderData, total); resolve(false); });
    } else {
      fallbackEmail(orderData, total);
      resolve(false);
    }
  });
}

function fallbackEmail(orderData, total) {
  let body = `NOUVELLE COMMANDE\nClient: ${orderData.nom} ${orderData.prenom}\nTel: ${orderData.telephone}\nTotal: ${total.toLocaleString()} FCFA`;
  window.location.href = `mailto:jspkite10@gmail.com?subject=${encodeURIComponent('Nouvelle commande Zone X')}&body=${encodeURIComponent(body)}`;
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();

  // Menu toggle
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('nav');
  if (toggle) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
    });
  }

  // Close menu on link click
  if (nav) {
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
      });
    });
  }
});
