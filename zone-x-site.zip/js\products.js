const products = [
  {
    id: 1,
    name: "Cagoule en Coton avec Hublot",
    price: 5000,
    category: "Masques & Cagoules",
    image: "images/cagoule-coton-hublo 5000frcfa.jpg",
    description: "Cagoule en coton de haute qualité avec hublot discret. Confortable et respirante, idéale pour les jeux de rôle et d'exploration sensorielle.",
    details: ["Matière : Coton premium", "Hublot intégré", "Respirant", "Taille unique", "Discret et élégant"]
  },
  {
    id: 2,
    name: "Fouet et Claque Fesses",
    price: 10000,
    category: "Accessoires BDSM",
    image: "images/fouet et claque fesses 10000frcfa.webp",
    description: "Ensemble fouet et claque-fesses en cuir synthétique. Parfait pour les amateurs de jeux de pouvoir et de sensations fortes.",
    details: ["Matière : Cuir synthétique", "Poignée ergonomique", "Lot de 2 pièces", "Usage léger à modéré"]
  },
  {
    id: 3,
    name: "Gode Pénis Réaliste",
    price: 20000,
    category: "Godes & Dildos",
    image: "images/gode pénis realiste 20000frcfa.jpg",
    description: "Gode pénis réaliste avec détails anatomiques précis. Texture douce et flexible pour un confort optimal.",
    details: ["Matière : Silicone médical", "Taille : 20 cm", "Réaliste", "Flexible", "Facile à nettoyer"]
  },
  {
    id: 4,
    name: "Gode Ceinture",
    price: 40000,
    category: "Godes & Dildos",
    image: "images/gode scenture 40000frcfa.webp",
    description: "Gode ceinture réglable pour une expérience mains libres. Idéal pour les couples cherchant à diversifier leurs jeux.",
    details: ["Matière : Silicone + nylon", "Taille réglable", "Confortable", "Mains libres", "Sangles ajustables"]
  },
  {
    id: 5,
    name: "Kit de Soumission",
    price: 38000,
    category: "Accessoires BDSM",
    image: "images/kit de soumission 38000frcfa.webp",
    description: "Kit complet de soumission incluant menottes, masque, fouet et accessoires. Le pack ultime pour explorer l'univers BDSM en toute sécurité.",
    details: ["Kit complet 6 pièces", "Menottes rembourrées", "Masque occultant", "Fouet", "Bâillon", "Pince tétons"]
  },
  {
    id: 6,
    name: "Langue Vibrante",
    price: 30000,
    category: "Vibrateurs",
    image: "images/langue vibrante 30000frcfa.jpg",
    description: "Langue vibrante avec multiples vitesses et motifs de vibration. Pour des sensations buccales électrisantes.",
    details: ["Matière : Silicone souple", "10 modes de vibration", "Rechargeable USB", "Étanche", "Silencieux"]
  },
  {
    id: 7,
    name: "Masque Basique en Cuir Foncé",
    price: 5000,
    category: "Masques & Cagoules",
    image: "images/masque-basique-en-cuir-fonc 5000frcfa.jpg",
    description: "Masque en cuir foncé élégant et confortable. Parfait pour les jeux de rôle et l'exploration sensorielle.",
    details: ["Matière : Cuir véritable", "Doublure intérieure douce", "Fermeture ajustable", "Design élégant", "Taille unique"]
  },
  {
    id: 8,
    name: "Menottes en Fourrure",
    price: 7000,
    category: "Accessoires BDSM",
    image: "images/ménotte en fourure 7000frcfa.jpg",
    description: "Menottes en fourrure douce et agréable au toucher. Allient confort et contention pour des moments de plaisir.",
    details: ["Matière : Fourrure synthétique", "Intérieur rembourré", "Fermeture sécurisée", "Confortables", "Légères"]
  },
  {
    id: 9,
    name: "Mini Poupée Sexuelle",
    price: 40000,
    category: "Poupées & Masturbateurs",
    image: "images/mini poupée sexuelle 40000frcfa.jpg",
    description: "Mini poupée sexuelle réaliste et compacte. Discrète et facile à ranger, elle offre un plaisir intense.",
    details: ["Matière : TPE premium", "Taille : 80 cm", "Corps articulé", "Orifices réalistes", "Facile à nettoyer"]
  },
  {
    id: 10,
    name: "Mini Vagin Artificiel",
    price: 25000,
    category: "Poupées & Masturbateurs",
    image: "images/mini vagin artificiel 25000frcfa.jpg",
    description: "Vagin artificiel compact aux textures internes variées pour des sensations uniques. Design discret et facile à utiliser.",
    details: ["Matière : TPE réaliste", "Texture interne variée", "Design compact", "Discret", "Facile d'entretien"]
  },
  {
    id: 11,
    name: "Mini Vibro",
    price: 8000,
    category: "Vibrateurs",
    image: "images/mini vibro 8000frcfa.jpg",
    description: "Mini vibreur compact et puissant. Parfait pour les débutants ou pour emporter partout discrètement.",
    details: ["Matière : Silicone médical", "3 vitesses", "Compact", "Discret", "Piles incluses"]
  },
  {
    id: 12,
    name: "Œuf Vibrant Télécommandé",
    price: 22000,
    category: "Vibrateurs",
    image: "images/Oeuf vibrant telecommandé 22000frcfa.jpg",
    description: "Œuf vibrant avec télécommande sans fil. Portez-le discrètement et laissez votre partenaire contrôler le plaisir à distance.",
    details: ["Matière : Silicone médical", "Télécommande sans fil", "10 modes", "Silencieux", "Portée : 10 mètres"]
  },
  {
    id: 13,
    name: "Pince Tétons",
    price: 5000,
    category: "Accessoires BDSM",
    image: "images/pince tétons 5000frcfa.webp",
    description: "Pinces à tétons réglables avec chaîne de connexion. Intensité ajustable pour tous les niveaux d'expérience.",
    details: ["Matière : Métal + silicone", "Pression réglable", "Chaîne décorative", "Confortables", "Sécurisées"]
  },
  {
    id: 14,
    name: "Plug Anal",
    price: 15000,
    category: "Accessoires",
    image: "images/plug anal 15000FRCFA.jpeg",
    description: "Plug anal en silicone médical avec base sécurisée. Design ergonomique pour un confort maximal et un plaisir progressif.",
    details: ["Matière : Silicone médical", "Base large sécurisée", "Taille : M", "Flexible", "Facile à nettoyer"]
  },
  {
    id: 15,
    name: "Rose Suceuse",
    price: 25000,
    category: "Vibrateurs",
    image: "images/rose suceuse 25000frcfa.webp",
    description: "Stimulateur en forme de rose avec technologie de succion. Design élégant et discret pour une stimulation clitoridienne intense.",
    details: ["Matière : Silicone hypoallergénique", "Technologie de succion", "10 modes", "Rechargeable USB", "Étanche IPX7"]
  },
  {
    id: 16,
    name: "Sex Toy Télécommandé Va-et-Vient",
    price: 40000,
    category: "Godes & Dildos",
    image: "images/sexetoy télécommandé vas et vient 40000frcfa.webp",
    description: "Sex toy automatique avec mouvement va-et-vient télécommandé. Pour une expérience réaliste et mains libres.",
    details: ["Matière : Silicone médical", "Mouvement automatique", "Télécommande sans fil", "10 vitesses", "Rechargeable USB"]
  }
];
